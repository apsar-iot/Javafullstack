
package com.example.simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(SimpleProjectApplication.class, args);
    }
}
