
package com.example.simple.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.simple.model.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {}
