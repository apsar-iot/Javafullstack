
package com.example.simple.controller;

import org.springframework.web.bind.annotation.*;
import com.example.simple.model.Project;
import com.example.simple.repo.ProjectRepository;
import java.util.List;

@RestController
@RequestMapping("/projects")
@CrossOrigin(origins = "http://localhost:3000")
public class ProjectController {
    private final ProjectRepository repo;
    public ProjectController(ProjectRepository repo) { this.repo = repo; }

    @GetMapping public List<Project> getAll() { return repo.findAll(); }
    @PostMapping public Project create(@RequestBody Project p) { return repo.save(p); }
}
